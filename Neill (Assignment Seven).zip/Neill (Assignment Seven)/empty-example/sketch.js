var placementY = [];
var x = [];
var c = 0;

function setup() {
    createCanvas(400, 400);
    var jerryTheVariable = [0, 1, 2, 4];
    print(jerryTheVariable.length);

    for (let a = 0; a < 10; a++) {
        x[a] = random(0, 400);
    }

}

function draw() {
    background(220);

    c += 2;

    for (let i = 0; i < 5; i++) {
        placementY[i] = i + c;
        print(placementY)
        print(c);
        for (let b = 0; b < 5; b++) {
            arc(x[b], placementY[b], 50, 50, PI, HALF_PI, PIE);
        }
        if (placementY[i] > 400) {
            placementY[i] = 0;
            c = 0;
        }
    }

}
