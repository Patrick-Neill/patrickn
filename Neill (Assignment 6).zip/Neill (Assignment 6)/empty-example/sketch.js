let rainstarty = 0;
let rainstartx = 0;
function setup() {
    createCanvas(400, 400);
    colorMode(RGB, 255);
}


function draw() {
    background(220);
    fill(45);
    ellipse(200, 20, 400, 55);
    angleMode(RADIANS);
    for (let x = 0; x < 20; x++) {
        rain(rainstartx + (25 * x), rainstarty);

    }
    if (rainstartx >= 400) {
        rainstartx = 0;
    }
    if (rainstarty >= 400) {
        rainstarty = 0;
    }
    rainstartx += 5;
    rainstarty += 5;
    print(rainstartx);
}

function rain(x, y) {
    push();
    noStroke();
    fill(175, 175, 255);
    rotate(PI / x);
    rect(x, y, 3, 55);
    scale(1.5);
    rotate(PI * y);
    rect(x, y + 75, 3, 55);
    scale(0.75);
    rotate(0);
    rect(x, y + 150, 3, 55);
    pop();
}