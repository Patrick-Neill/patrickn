let color1 = 200;
let color2 = 100;
let color3 = 200;

function setup() {
    createCanvas(400, 400);
    colorMode(RGB, 255);
}

function draw() {
    background(255, 100, 0);
    fill(75, 75, 200);
    rect(10, 10, 380, 350);
    fill(color1, 100, 0);
    rect(75, 250, 100, 50);
    fill(200, color2, 0);
    rect(225, 250, 100, 50);
    fill(0, 0, color3)
    rect(25, 25, 350, 200);
    if (keyIsPressed == true) {
        if (mouseX >= 25 && mouseX <= 375 && mouseY >= 25 && mouseY <= 225) {
            color3 = 0;
        }
    }
}

function mouseClicked() {
    if (mouseX >= 75 && mouseX <= 175 && mouseY >= 250 && mouseY <= 300) {
        if (color1 == 200) {
            color1 = 150;
        }
        else {
            color1 = 200;
        }
    }
    if (mouseX >= 225 && mouseX <= 325 && mouseY >= 250 && mouseY <= 300) {
        if (color2 == 100) {
            color2 = 75;
            color3 = 200;
        }
        else {
            color2 = 100;
            color3 = 200;
        }
    }
}
